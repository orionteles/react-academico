import React from 'react';
import { BrowserRouter, Route } from 'react-router-dom';
import Cabecalho from './components/Cabecalho';
import AlunoForm from './pages/alunos/AlunoForm';
import Alunos from './pages/alunos/Alunos';
import CursoForm from './pages/cursos/CursoForm';
import Cursos from './pages/cursos/Cursos';
import Professores from './pages/professores/Professores';
import ProfessorForm from './pages/professores/ProfessorForm';
import SalaForm from './pages/sala/SalaForm';
import Salas from './pages/sala/Salas';

export default () => {
  return (
    <>
      <BrowserRouter>
        <Cabecalho />
        <Route exact path="/alunos" component={Alunos} />
        <Route exact path="/alunos/create" component={AlunoForm} />
        <Route exact path="/alunos/:id/edit" component={AlunoForm} />
        <Route exact path="/cursos" component={Cursos} />
        <Route exact path="/cursos/create" component={CursoForm} />
        <Route exact path="/salas" component={Salas} />
        <Route exact path="/salas/create" component={SalaForm} />
        <Route exact path="/professores" component={Professores} />
        <Route exact path="/professores/create" component={ProfessorForm} />
      </BrowserRouter>
    </>
  )
}