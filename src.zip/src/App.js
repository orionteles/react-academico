import React from 'react'
import Rotas from './Rotas'

import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <>
      <Rotas />
    </>
  );
}

export default App;
